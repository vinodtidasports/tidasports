<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Stripe_payment extends REST_Controller  {
    function __construct()
    {
        parent::__construct();
        $this->load->library('Uuid');
        $this->load->model('Users_Model');
        $this->load->helper('common_helper');
        $UserId = trim($this->post('userid'));
        $token = trim($this->post('token'));
        $tbl = 'tbl_venue';
        $checktoken = $this->Users_Model->CheckLoginUserKey($UserId,$token);
        if($checktoken==0)
        {
            $this->response([
                  'status' => FALSE,
                  'message' => 'Session Expired. Please Login Again.'
              ], REST_Controller::HTTP_OK);
        }
    }
    public function customer_post()
    {
        $amount = $this->input->post('amount');
         $userid = $this->input->post('userid');
        $order_id = $this->input->post('order_id'); 
        if($userid){
            $get_user = $this->Users_Model->getTblData('tbl_user','id',$userid);
            $user = $get_user[0]; 
            $email = $user->email;
        }
        require 'stripe/vendor/autoload.php';
        $stripe = new \Stripe\StripeClient('sk_test_51Mt0RRSGsP3uGRrnPqDsy1KPgyU5qsh40zhuBF5unxpnTNeDpwpiKW84fC83Gk4XUMsxF0IFYjjtrEP4OH8sJNa7007GX5XdsJ');
        /*$search_customer = $stripe->customers->search([
        'query' => 'email:\'$email\' AND description:\'$userid\'',
        ]); echo  'search_customer';  print_r($search_customer);*/
        $customer = $stripe->customers->create([
            'email' => $email,
            'metadata'=> [
                'CustomerReferenceId'=> $userid,
            ]
        ]); 
        $ephemeralKey = $stripe->ephemeralKeys->create([
            'customer' => $customer->id,
        ], [
        'stripe_version' => '2022-08-01',
        ]);
        $paymentIntent = $stripe->paymentIntents->create([
        'amount' => $amount,
        'currency' => 'INR',
        'customer' => $customer->id,
        'description' => $order_id,
        'automatic_payment_methods' => [
            'enabled' => 'true',
        ],
        'receipt_email' => $email
        ]);
        echo json_encode(
        [
            'paymentIntent' => $paymentIntent->client_secret,
            'ephemeralKey' => $ephemeralKey->secret,
            'customer' => $customer->id,
            'publishableKey' => 'pk_test_51Mt0RRSGsP3uGRrnYFSSBXrk1GYWTOv2FUwK3hyt67VLs8ToQRxT14432RJcjgWy0T6msA0EgE3UJ8GMv9ey4GXp003rHLJX78'
        ]
        );
        die;
        http_response_code(200);
        $checkout_session = $stripe->checkout->sessions->create([
            'line_items' => [[
                'price_data' => [
                'currency' => 'usd',
                'product_data' => [
                    'name' => 'T-shirt',
                ],
                'unit_amount' => 2000,
                ],
                'quantity' => 1,
            ]],
            'mode' => 'payment',
            'success_url' => 'https://tidasports.com',
            'cancel_url' => 'https://tidasports.com',
        ]);
    }
}