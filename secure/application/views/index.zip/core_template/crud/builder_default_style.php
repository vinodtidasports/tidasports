<?php foreach ($this->crud_builder->getFieldShowInColumn(true) as $input => $option) : ?>
   /* .<?= $option['wrapper_class'] ?> */
   .<?= $option['wrapper_class'] ?> {

   }

   .<?= $option['wrapper_class'] ?> .control-label {

   }

   .<?= $option['wrapper_class'] ?> .col-sm-8 {

   }

   .<?= $option['wrapper_class'] ?> .form-control {

   }

   .<?= $option['wrapper_class'] ?> .help-block {

   }
   /* end .<?= $option['wrapper_class'] ?> */



<?php endforeach ?>