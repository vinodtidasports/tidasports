function beforeSave() {
//$save_data['_example'] = $this->input->post('_example');
}

function afterSuccess($id){
}